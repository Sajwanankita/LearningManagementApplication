export interface Teacher{
    name : string
}