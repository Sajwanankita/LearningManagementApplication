export interface Subject{
    name : string
    courseId: number
}